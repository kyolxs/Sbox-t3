# T-typeAES
The file T-aes obtains the resource estimates of our T-type AES with Q# programming language. The file W-type S-box verifies the correctness of the implementations of our W-type S-box.
